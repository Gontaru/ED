
En este fichero se especifican los pasos para instalar el programa main_imagen.cpp y sus instrucciones para un buen uso:

	1) Para instalar el programa abrimo la consola y nos dirijimos al directorio imagen/

	2) Ejecutamos make

	3) Ejecutamos el programa ./main_imagen 
	
	(Nota: se ha optado por ejecutar el programa sin parámetros, y una vez dentro cargar la imagen a tratar y hacerle las operaciones 		oportunas. Es necesario tener las imágenes en el mismo directorio que el ejecutable main_imagen).
	
	4) Una vez dentro tenemos un menú con opciones:
		
		C: Cargar imagen
		G: Guardar imagen
		1: Umbralizar imagen automáticamente
		2: Leer mensaje cifrado
		3: Cifrar mensaje
		4: Umbralizar imagen con escala de grises
		5: Negativo de una imagen
		6: Enmarcar imagen
		7: Zoom de una omagen
		8: Aumentar contraste de una imagen
		9: Generar icono de una imagen
		E: Salir del programa

	Para realizar operaciones o guardar, primero será necesario cargar una imagen con la opción C.


